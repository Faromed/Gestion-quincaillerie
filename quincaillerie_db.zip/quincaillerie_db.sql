-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : ven. 25 avr. 2025 à 17:36
-- Version du serveur :  5.7.31
-- Version de PHP : 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `quincaillerie_db`
--

-- --------------------------------------------------------

--
-- Structure de la table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES
(2, 'Plomberie', 'Tout ce qui a rapport avec la plomberie', '2025-04-24 17:30:02', '2025-04-24 17:30:02');

-- --------------------------------------------------------

--
-- Structure de la table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `barcode` varchar(100) DEFAULT NULL,
  `reference` varchar(100) DEFAULT NULL,
  `category_id` int(11) UNSIGNED NOT NULL,
  `purchase_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `sale_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `current_stock` int(11) NOT NULL DEFAULT '0',
  `alert_threshold` int(11) NOT NULL DEFAULT '0',
  `location` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `barcode` (`barcode`),
  UNIQUE KEY `reference` (`reference`),
  KEY `category_id` (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `products`
--

INSERT INTO `products` (`id`, `name`, `barcode`, `reference`, `category_id`, `purchase_price`, `sale_price`, `current_stock`, `alert_threshold`, `location`, `image`, `created_at`, `updated_at`) VALUES
(1, 'Tuyau PVC', NULL, '14425', 2, '1500.00', '3000.00', 62, 5, 'Cotonou', 'assets/img/products/680b45e6115ca.jpg', '2025-04-24 17:40:30', '2025-04-25 09:00:27'),
(2, 'Anneau tuyau', NULL, '12425', 2, '1500.00', '2500.00', 287, 20, 'Cotonou', 'assets/img/products/680b38d9c7ef7.jpg', '2025-04-25 07:25:13', '2025-04-25 08:21:43'),
(3, 'Mini  imprimante', NULL, '12426', 2, '15000.00', '25000.00', 49, 5, 'Cotonou', 'assets/img/products/680b4579b5a08.jpg', '2025-04-25 08:19:05', '2025-04-25 08:21:43'),
(4, 'Montre connecté', NULL, '12427', 2, '5000.00', '12000.00', 33, 5, 'Bohicon', 'assets/img/products/680b45bd637d5.jpg', '2025-04-25 08:20:13', '2025-04-25 08:21:43'),
(7, 'Tuyau PVC', NULL, '14431', 2, '1500.00', '3000.00', 62, 5, 'Cotonou', 'assets/img/products/680b696fb9909.jpg', '2025-04-25 10:49:23', '2025-04-25 10:52:31'),
(8, 'Mini  imprimante', NULL, '12433', 2, '15000.00', '25000.00', 49, 5, 'Cotonou', 'assets/img/products/680b697c56da4.jpg', '2025-04-25 10:51:51', '2025-04-25 10:52:44'),
(9, 'Montre connecté', NULL, '12434', 2, '5000.00', '12000.00', 24, 5, 'Bohicon', NULL, '2025-04-25 10:51:51', '2025-04-25 11:14:02'),
(10, 'Tuyau PVC', NULL, '14435', 2, '1500.00', '3000.00', 62, 5, 'Cotonou', NULL, '2025-04-25 10:51:51', '2025-04-25 10:51:51');

-- --------------------------------------------------------

--
-- Structure de la table `purchase_orders`
--

DROP TABLE IF EXISTS `purchase_orders`;
CREATE TABLE IF NOT EXISTS `purchase_orders` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `order_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `supplier_id` int(11) UNSIGNED NOT NULL,
  `total_amount` decimal(10,2) NOT NULL COMMENT 'Montant total de la commande fournisseur',
  `status` enum('Pending','Sent','Received','Cancelled') NOT NULL DEFAULT 'Pending' COMMENT 'Statut de la commande',
  `user_id` int(11) UNSIGNED DEFAULT NULL COMMENT 'Utilisateur qui a créé la commande',
  `notes` text COMMENT 'Notes sur la commande',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `purchase_orders`
--

INSERT INTO `purchase_orders` (`id`, `order_date`, `supplier_id`, `total_amount`, `status`, `user_id`, `notes`, `created_at`, `updated_at`) VALUES
(1, '2025-04-25 11:02:08', 2, '225000.00', 'Pending', 1, NULL, '2025-04-25 11:02:08', '2025-04-25 11:02:08'),
(2, '2025-04-25 11:08:10', 2, '225000.00', 'Pending', 1, 'J\'ai besoin de ces produits en urgence', '2025-04-25 11:08:10', '2025-04-25 11:08:10'),
(3, '2025-04-25 13:05:55', 1, '45000.00', 'Pending', 1, NULL, '2025-04-25 13:05:55', '2025-04-25 13:05:55'),
(4, '2025-04-25 13:06:24', 1, '1500.00', 'Pending', 1, NULL, '2025-04-25 13:06:24', '2025-04-25 13:06:24'),
(5, '2025-04-25 14:13:16', 1, '1500.00', 'Pending', 1, NULL, '2025-04-25 14:13:16', '2025-04-25 14:13:16');

-- --------------------------------------------------------

--
-- Structure de la table `purchase_order_items`
--

DROP TABLE IF EXISTS `purchase_order_items`;
CREATE TABLE IF NOT EXISTS `purchase_order_items` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `purchase_order_id` int(11) UNSIGNED NOT NULL,
  `product_id` int(11) UNSIGNED NOT NULL,
  `quantity_ordered` int(11) NOT NULL,
  `quantity_received` int(11) NOT NULL DEFAULT '0' COMMENT 'Quantité reçue pour cet article',
  `unit_price` decimal(10,2) NOT NULL COMMENT 'Prix d''achat unitaire AU MOMENT de la commande',
  `line_total` decimal(10,2) NOT NULL COMMENT 'quantity_ordered * unit_price',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `purchase_order_id` (`purchase_order_id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `purchase_order_items`
--

INSERT INTO `purchase_order_items` (`id`, `purchase_order_id`, `product_id`, `quantity_ordered`, `quantity_received`, `unit_price`, `line_total`, `created_at`) VALUES
(1, 1, 8, 15, 0, '15000.00', '225000.00', '2025-04-25 11:02:08'),
(2, 2, 9, 10, 0, '5000.00', '50000.00', '2025-04-25 11:08:10'),
(3, 2, 4, 5, 0, '5000.00', '25000.00', '2025-04-25 11:08:10'),
(4, 2, 3, 10, 0, '15000.00', '150000.00', '2025-04-25 11:08:10'),
(5, 3, 3, 3, 0, '15000.00', '45000.00', '2025-04-25 13:05:55'),
(6, 4, 7, 1, 0, '1500.00', '1500.00', '2025-04-25 13:06:24'),
(7, 5, 10, 1, 0, '1500.00', '1500.00', '2025-04-25 14:13:16');

-- --------------------------------------------------------

--
-- Structure de la table `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `roles`
--

INSERT INTO `roles` (`id`, `name`, `description`) VALUES
(1, 'Administrateur', 'Accès complet au système'),
(2, 'Vendeur', 'Gestion des ventes et consultation'),
(3, 'Stockiste', 'Gestion des stocks et consultation');

-- --------------------------------------------------------

--
-- Structure de la table `sales`
--

DROP TABLE IF EXISTS `sales`;
CREATE TABLE IF NOT EXISTS `sales` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `sale_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `total_amount` decimal(10,2) NOT NULL COMMENT 'Sous-total avant taxes et remises',
  `tax_amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT 'Montant de la taxe appliquée',
  `discount_amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT 'Montant de la remise appliquée',
  `final_amount` decimal(10,2) NOT NULL COMMENT 'Montant final payé par le client',
  `user_id` int(11) UNSIGNED DEFAULT NULL COMMENT 'Utilisateur (Vendeur) qui a enregistré la vente',
  `customer_name` varchar(255) DEFAULT NULL COMMENT 'Nom du client (optionnel)',
  `notes` text COMMENT 'Notes sur la vente (optionnel)',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `sales`
--

INSERT INTO `sales` (`id`, `sale_date`, `total_amount`, `tax_amount`, `discount_amount`, `final_amount`, `user_id`, `customer_name`, `notes`, `created_at`, `updated_at`) VALUES
(1, '2025-04-25 06:52:29', '30000.00', '5400.00', '0.00', '35400.00', 1, NULL, NULL, '2025-04-25 06:52:29', '2025-04-25 06:52:29'),
(2, '2025-04-25 07:25:55', '2500.00', '450.00', '0.00', '2950.00', 1, 'Farel Medenou', 'besoin', '2025-04-25 07:25:55', '2025-04-25 07:25:55'),
(3, '2025-04-25 07:26:22', '5500.00', '990.00', '0.00', '6490.00', 1, NULL, NULL, '2025-04-25 07:26:22', '2025-04-25 07:26:22'),
(4, '2025-04-25 07:34:00', '5000.00', '900.00', '0.00', '5900.00', 1, NULL, NULL, '2025-04-25 07:34:00', '2025-04-25 07:34:00'),
(5, '2025-04-25 08:00:15', '2500.00', '450.00', '0.00', '2950.00', 1, NULL, NULL, '2025-04-25 08:00:15', '2025-04-25 08:00:15'),
(6, '2025-04-25 08:11:34', '12500.00', '2250.00', '0.00', '14750.00', 2, NULL, NULL, '2025-04-25 08:11:34', '2025-04-25 08:11:34'),
(7, '2025-04-25 08:13:06', '2500.00', '450.00', '0.00', '2950.00', 1, NULL, NULL, '2025-04-25 08:13:06', '2025-04-25 08:13:06'),
(8, '2025-04-25 08:21:43', '57000.00', '10260.00', '0.00', '67260.00', 1, 'Mr Gbaguidi', NULL, '2025-04-25 08:21:43', '2025-04-25 08:21:43'),
(9, '2025-04-25 08:59:46', '15000.00', '2700.00', '0.00', '17700.00', 1, NULL, NULL, '2025-04-25 08:59:46', '2025-04-25 08:59:46'),
(10, '2025-04-25 11:14:02', '108000.00', '19440.00', '0.00', '127440.00', 1, NULL, NULL, '2025-04-25 11:14:02', '2025-04-25 11:14:02');

-- --------------------------------------------------------

--
-- Structure de la table `sale_items`
--

DROP TABLE IF EXISTS `sale_items`;
CREATE TABLE IF NOT EXISTS `sale_items` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) UNSIGNED NOT NULL,
  `product_id` int(11) UNSIGNED NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL COMMENT 'Prix de vente unitaire AU MOMENT de la vente',
  `line_total` decimal(10,2) NOT NULL COMMENT 'quantity * unit_price',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `sale_items`
--

INSERT INTO `sale_items` (`id`, `sale_id`, `product_id`, `quantity`, `unit_price`, `line_total`, `created_at`) VALUES
(1, 1, 1, 10, '3000.00', '30000.00', '2025-04-25 06:52:29'),
(2, 2, 2, 1, '2500.00', '2500.00', '2025-04-25 07:25:55'),
(3, 3, 1, 1, '3000.00', '3000.00', '2025-04-25 07:26:22'),
(4, 3, 2, 1, '2500.00', '2500.00', '2025-04-25 07:26:22'),
(5, 4, 2, 2, '2500.00', '5000.00', '2025-04-25 07:34:00'),
(6, 5, 2, 1, '2500.00', '2500.00', '2025-04-25 08:00:15'),
(7, 6, 2, 5, '2500.00', '12500.00', '2025-04-25 08:11:34'),
(8, 7, 2, 1, '2500.00', '2500.00', '2025-04-25 08:13:06'),
(9, 8, 2, 2, '2500.00', '5000.00', '2025-04-25 08:21:43'),
(10, 8, 3, 1, '25000.00', '25000.00', '2025-04-25 08:21:43'),
(11, 8, 4, 2, '12000.00', '24000.00', '2025-04-25 08:21:43'),
(12, 8, 1, 1, '3000.00', '3000.00', '2025-04-25 08:21:43'),
(13, 9, 1, 5, '3000.00', '15000.00', '2025-04-25 08:59:46'),
(14, 10, 9, 9, '12000.00', '108000.00', '2025-04-25 11:14:02');

-- --------------------------------------------------------

--
-- Structure de la table `stock_movements`
--

DROP TABLE IF EXISTS `stock_movements`;
CREATE TABLE IF NOT EXISTS `stock_movements` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_id` int(11) UNSIGNED NOT NULL,
  `movement_type` enum('Entree - Ajustement','Sortie - Casse','Sortie - Usage Interne','Entree - Approvisionnement','Sortie - Vente','Entree - Retour Client','Sortie - Retour Fournisseur') NOT NULL COMMENT 'Type de mouvement (manuel ou automatique)',
  `quantity` int(11) NOT NULL COMMENT 'Quantité positive pour une entrée, négative pour une sortie',
  `notes` text COMMENT 'Raison ou commentaire',
  `user_id` int(11) UNSIGNED DEFAULT NULL COMMENT 'Utilisateur ayant enregistré le mouvement',
  `movement_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Date et heure du mouvement',
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `stock_movements`
--

INSERT INTO `stock_movements` (`id`, `product_id`, `movement_type`, `quantity`, `notes`, `user_id`, `movement_date`) VALUES
(1, 1, 'Sortie - Vente', -10, 'Vente #1 (10 x Tuyau PVC)', 1, '2025-04-25 06:52:29'),
(2, 2, 'Sortie - Vente', -1, 'Vente #2 (1 x Anneau tuyau)', 1, '2025-04-25 07:25:55'),
(3, 1, 'Sortie - Vente', -1, 'Vente #3 (1 x Tuyau PVC)', 1, '2025-04-25 07:26:22'),
(4, 2, 'Sortie - Vente', -1, 'Vente #3 (1 x Anneau tuyau)', 1, '2025-04-25 07:26:22'),
(5, 2, 'Sortie - Vente', -2, 'Vente #4 (2 x Anneau tuyau)', 1, '2025-04-25 07:34:00'),
(6, 2, 'Sortie - Vente', -1, 'Vente #5 (1 x Anneau tuyau)', 1, '2025-04-25 08:00:15'),
(7, 2, 'Sortie - Vente', -5, 'Vente #6 (5 x Anneau tuyau)', 2, '2025-04-25 08:11:34'),
(8, 2, 'Sortie - Vente', -1, 'Vente #7 (1 x Anneau tuyau)', 1, '2025-04-25 08:13:06'),
(9, 2, 'Sortie - Vente', -2, 'Vente #8 (2 x Anneau tuyau)', 1, '2025-04-25 08:21:43'),
(10, 3, 'Sortie - Vente', -1, 'Vente #8 (1 x Mini  imprimante)', 1, '2025-04-25 08:21:43'),
(11, 4, 'Sortie - Vente', -2, 'Vente #8 (2 x Montre connecté)', 1, '2025-04-25 08:21:43'),
(12, 1, 'Sortie - Vente', -1, 'Vente #8 (1 x Tuyau PVC)', 1, '2025-04-25 08:21:43'),
(13, 1, 'Sortie - Vente', -5, 'Vente #9 (5 x Tuyau PVC)', 1, '2025-04-25 08:59:46'),
(14, 9, 'Sortie - Vente', -9, 'Vente #10 (9 x Montre connecté)', 1, '2025-04-25 11:14:02');

-- --------------------------------------------------------

--
-- Structure de la table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
CREATE TABLE IF NOT EXISTS `suppliers` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `contact_person` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `address` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `suppliers`
--

INSERT INTO `suppliers` (`id`, `name`, `contact_person`, `email`, `phone`, `address`, `created_at`, `updated_at`) VALUES
(1, 'Farel Aubin Medenou', '+2290161228165', 'farelmedenou2018@gmail.com', '61228165', 'agblome\r\nhounli', '2025-04-24 17:53:35', '2025-04-24 17:53:35'),
(2, 'ZOLA Paterne', '+2290140182605', 'pato@gmail.com', '+2290140182605', 'Lokossa', '2025-04-24 17:54:33', '2025-04-24 17:54:33');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role_id` int(11) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `role_id` (`role_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role_id`, `created_at`, `updated_at`) VALUES
(1, 'admin', '$2y$10$3hEHKY6L3Mmt2DPAL13Y2usNnfzZJxQY75WS5/qDBv4lTNh3s7xDq', 1, '2025-04-24 17:12:05', '2025-04-24 17:12:05'),
(2, 'Faromed', '$2y$10$qy7AGCnHqf4.UEbPON0hH.3dQ7Pm1H5ZVKBhwzrC4LPpqMp24pVla', 2, '2025-04-25 08:09:46', '2025-04-25 08:09:46');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
